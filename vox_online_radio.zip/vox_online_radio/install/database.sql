-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 14, 2023 at 07:37 AM
-- Server version: 10.3.38-MariaDB-log-cll-lve
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nemosofts_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_active_log`
--

CREATE TABLE `tbl_active_log` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `date_time` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `email` varchar(200) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  `admin_type` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `username`, `password`, `email`, `image`, `status`, `admin_type`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'info.nemosofts@gmail.com', '57317_profile.png', 1, 3),
(2, 'nemosofts', 'e635fcb9940f4f061c5b283d6ed24cc0', 'thiva.nemosofts@gmail.com', '', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_banner`
--

CREATE TABLE `tbl_banner` (
  `bid` int(11) NOT NULL,
  `banner_title` varchar(255) NOT NULL,
  `banner_info` varchar(500) NOT NULL,
  `banner_image` varchar(255) NOT NULL,
  `banner_post_id` text NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cid` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_image` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_countries`
--

CREATE TABLE `tbl_countries` (
  `sid` int(11) NOT NULL,
  `countries_name` varchar(255) NOT NULL,
  `countries_image` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_episode`
--

CREATE TABLE `tbl_episode` (
  `id` int(11) NOT NULL,
  `podcast_id` int(11) NOT NULL,
  `episode_title` varchar(255) NOT NULL,
  `episode_url` text NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_favourite`
--

CREATE TABLE `tbl_favourite` (
  `id` int(10) NOT NULL,
  `post_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `created_at` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_home_sections`
--

CREATE TABLE `tbl_home_sections` (
  `id` int(11) NOT NULL,
  `section_name` varchar(255) NOT NULL,
  `section_type` varchar(255) DEFAULT NULL,
  `post_ids` text DEFAULT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_notification`
--

CREATE TABLE `tbl_notification` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `notification_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `notification_msg` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `notification_on` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_podcast`
--

CREATE TABLE `tbl_podcast` (
  `pid` int(11) NOT NULL,
  `podcast_name` varchar(255) NOT NULL,
  `podcast_image` varchar(255) NOT NULL,
  `podcast_description` text NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_policy_deletion`
--

CREATE TABLE `tbl_policy_deletion` (
  `id` int(11) NOT NULL,
  `policy_type` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `report_msg` text NOT NULL,
  `deletion_on` varchar(200) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_radio`
--

CREATE TABLE `tbl_radio` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `countries_id` int(11) NOT NULL,
  `radio_title` varchar(255) NOT NULL,
  `radio_url` text NOT NULL,
  `radio_image` varchar(255) NOT NULL,
  `radio_description` text NOT NULL,
  `isPremium` varchar(20) NOT NULL DEFAULT 'false',
  `rate_avg` int(11) NOT NULL DEFAULT 0,
  `total_rate` int(11) NOT NULL DEFAULT 0,
  `total_views` int(11) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_radio_views`
--

CREATE TABLE `tbl_radio_views` (
  `view_id` bigint(20) NOT NULL,
  `radio_id` bigint(20) NOT NULL,
  `views` bigint(20) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rating`
--

CREATE TABLE `tbl_rating` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `device_id` varchar(40) NOT NULL,
  `rate` int(11) NOT NULL,
  `message` text NOT NULL,
  `dt_rate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_reports`
--

CREATE TABLE `tbl_reports` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `report_title` varchar(255) NOT NULL,
  `report_msg` text NOT NULL,
  `report_on` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_settings`
--

CREATE TABLE `tbl_settings` (
  `id` int(11) NOT NULL,
  `app_name` varchar(100) NOT NULL,
  `app_logo` varchar(200) NOT NULL,
  `app_email` varchar(100) NOT NULL,
  `app_author` varchar(100) NOT NULL,
  `app_contact` varchar(100) NOT NULL,
  `app_website` varchar(150) NOT NULL,
  `app_description` text NOT NULL,
  `app_developed_by` varchar(150) NOT NULL,
  `app_privacy_policy` text NOT NULL,
  `app_terms` text NOT NULL,
  `account_delete_intruction` text NOT NULL,
  `envato_buyer_name` varchar(100) NOT NULL,
  `envato_purchase_code` text NOT NULL,
  `envato_package_name` varchar(150) NOT NULL,
  `envato_api_key` text NOT NULL,
  `onesignal_app_id` text NOT NULL,
  `onesignal_rest_key` text NOT NULL,
  `home_limit` int(2) NOT NULL DEFAULT 10,
  `api_latest_limit` int(2) NOT NULL DEFAULT 10,
  `api_cat_order_by` varchar(150) NOT NULL DEFAULT 'category_name',
  `api_cat_post_order_by` varchar(150) NOT NULL DEFAULT 'DESC',
  `app_api_key` varchar(150) NOT NULL,
  `isRTL` varchar(10) NOT NULL DEFAULT 'false',
  `isMaintenance` varchar(10) NOT NULL DEFAULT 'false',
  `isScreenshot` varchar(10) NOT NULL DEFAULT 'false',
  `isGoogleLogin` varchar(10) NOT NULL DEFAULT 'true',
  `isLogin` varchar(10) NOT NULL DEFAULT 'true',
  `isAPK` varchar(10) NOT NULL DEFAULT 'false',
  `isVPN` varchar(10) NOT NULL DEFAULT 'false',
  `isDummy_1` varchar(10) NOT NULL DEFAULT 'false',
  `isDummy_2` varchar(10) NOT NULL DEFAULT 'false',
  `dummy_test_1` varchar(150) NOT NULL,
  `dummy_test_2` varchar(150) NOT NULL,
  `app_update_status` varchar(10) NOT NULL DEFAULT 'false',
  `app_new_version` double NOT NULL DEFAULT 1,
  `app_update_desc` text NOT NULL,
  `app_redirect_url` text NOT NULL,
  `ad_network` varchar(30) NOT NULL DEFAULT 'admob',
  `publisher_id` text NOT NULL,
  `start_ads_id` text NOT NULL,
  `unity_ads_id` text NOT NULL,
  `iron_ads_id` text NOT NULL,
  `wortise_app_id` text NOT NULL,
  `banner_ad` varchar(10) NOT NULL DEFAULT 'true',
  `banner_ad_id` text NOT NULL,
  `banner_facebook_id` text NOT NULL,
  `banner_applovins_id` text NOT NULL,
  `banner_wortise_id` text NOT NULL,
  `interstital_ad` varchar(10) NOT NULL DEFAULT 'true',
  `interstital_ad_id` text NOT NULL,
  `interstital_facebook_id` text NOT NULL,
  `interstital_applovins_id` text NOT NULL,
  `interstital_wortise_id` text NOT NULL,
  `interstital_ad_click` int(10) NOT NULL DEFAULT 5,
  `native_ad` varchar(10) NOT NULL DEFAULT 'true',
  `native_ad_id` text NOT NULL,
  `native_facebook_id` text NOT NULL,
  `native_applovins_id` text NOT NULL,
  `native_wortise_id` text NOT NULL,
  `native_position` int(10) NOT NULL DEFAULT 5,
  `ads_limits` varchar(10) NOT NULL DEFAULT 'true',
  `ads_count_click` int(10) NOT NULL DEFAULT 20,
  `custom_ads` varchar(10) NOT NULL DEFAULT 'false',
  `custom_ads_img` varchar(200) NOT NULL,
  `custom_ads_link` text NOT NULL,
  `custom_ads_clicks` int(10) NOT NULL DEFAULT 12
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_settings`
--

INSERT INTO `tbl_settings` (`id`, `app_name`, `app_logo`, `app_email`, `app_author`, `app_contact`, `app_website`, `app_description`, `app_developed_by`, `app_privacy_policy`, `app_terms`, `account_delete_intruction`, `envato_buyer_name`, `envato_purchase_code`, `envato_package_name`, `envato_api_key`, `onesignal_app_id`, `onesignal_rest_key`, `home_limit`, `api_latest_limit`, `api_cat_order_by`, `api_cat_post_order_by`, `app_api_key`, `isRTL`, `isMaintenance`, `isScreenshot`, `isGoogleLogin`, `isLogin`, `isAPK`, `isVPN`, `isDummy_1`, `isDummy_2`, `dummy_test_1`, `dummy_test_2`, `app_update_status`, `app_new_version`, `app_update_desc`, `app_redirect_url`, `ad_network`, `publisher_id`, `start_ads_id`, `unity_ads_id`, `iron_ads_id`, `wortise_app_id`, `banner_ad`, `banner_ad_id`, `banner_facebook_id`, `banner_applovins_id`, `banner_wortise_id`, `interstital_ad`, `interstital_ad_id`, `interstital_facebook_id`, `interstital_applovins_id`, `interstital_wortise_id`, `interstital_ad_click`, `native_ad`, `native_ad_id`, `native_facebook_id`, `native_applovins_id`, `native_wortise_id`, `native_position`, `ads_limits`, `ads_count_click`, `custom_ads`, `custom_ads_img`, `custom_ads_link`, `custom_ads_clicks`) VALUES
(1, 'VOX Online Radio', '51177_logo.png', 'info.nemosofts@gmail.com', 'nemosofts', '0356525684', 'nemosofts.com', 'Love this app? Let us Know in the Google Play Store how we can make it even better', 'thivakaran', '', '', '', '', '', '', '', '', '', 10, 50, 'category_name', 'DESC', '', 'false', 'false', 'false', 'true', 'true', 'false', 'false', 'true', 'false', '', '', 'false', 1, 'update note', 'https://play.google.com/store/apps/details', 'wortise', '', '', '', '', '00000000-0000-0000-0000-123456789abc', 'true', '', '', '', 'test-banner', 'true', '', '', '', 'test-interstitial', 5, 'true', '', '', '', 'test-native', 5, 'true', 20, 'true', 'https://camo.envatousercontent.com/47d826c1e095bc24a744c5f014330a03318ae300/68747470733a2f2f646f776e6c6f61642e6e656d6f736f6674732e636f6d2f656e7661746f2f72657364657369676e2e706e67', 'https://codecanyon.net/user/nemosofts', 12);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sidebar`
--

CREATE TABLE `tbl_sidebar` (
  `id` int(11) NOT NULL,
  `sidebar_type` varchar(255) NOT NULL,
  `sidebar_title` varchar(255) NOT NULL,
  `sidebar_icon` varchar(255) NOT NULL,
  `sidebar_editor` text NOT NULL,
  `sidebar_html` text NOT NULL,
  `sidebar_image` text NOT NULL,
  `sidebar_image_link` text NOT NULL DEFAULT '#',
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tbl_sidebar`
--

INSERT INTO `tbl_sidebar` (`id`, `sidebar_type`, `sidebar_title`, `sidebar_icon`, `sidebar_editor`, `sidebar_html`, `sidebar_image`, `sidebar_image_link`, `status`) VALUES
(2, 'visual_editor', 'Visual Editor', 'ri-question-answer-fill', '<div><div>This is developed using the popular PHP framework <b>Codeigniter</b>. <font color=\"#ff0000\">Online Radio</font> this is website application for Radio.</div></div><div><br></div>', '', '', '', 1),
(4, 'html_code', 'HTML Editor', 'ri-question-answer-line', '', '<h3>My First Heading</h3>\r\n<p>This is another paragraph.</p>\r\n<p><b>This text is bold</b></p>\r\n<p><i>This text is italic</i></p>\r\n<p>This is<sub> subscript</sub> and <sup>superscript</sup></p>', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_smtp_settings`
--

CREATE TABLE `tbl_smtp_settings` (
  `id` int(5) NOT NULL,
  `smtp_type` varchar(20) NOT NULL DEFAULT 'server',
  `smtp_host` varchar(150) NOT NULL,
  `smtp_email` varchar(150) NOT NULL,
  `smtp_password` text NOT NULL,
  `smtp_secure` varchar(20) NOT NULL,
  `port_no` varchar(10) NOT NULL,
  `smtp_ghost` varchar(150) NOT NULL,
  `smtp_gemail` varchar(150) NOT NULL,
  `smtp_gpassword` text NOT NULL,
  `smtp_gsecure` varchar(20) NOT NULL,
  `gport_no` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tbl_smtp_settings`
--

INSERT INTO `tbl_smtp_settings` (`id`, `smtp_type`, `smtp_host`, `smtp_email`, `smtp_password`, `smtp_secure`, `port_no`, `smtp_ghost`, `smtp_gemail`, `smtp_gpassword`, `smtp_gsecure`, `gport_no`) VALUES
(1, 'gmail', '', '', '', 'ssl', '465', '', '', '', 'tls', 587);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_subscription`
--

CREATE TABLE `tbl_subscription` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `duration` text NOT NULL,
  `price` text NOT NULL,
  `currency_code` text NOT NULL,
  `subscription_id` text NOT NULL,
  `base_key` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tbl_subscription`
--

INSERT INTO `tbl_subscription` (`id`, `name`, `duration`, `price`, `currency_code`, `subscription_id`, `base_key`) VALUES
(1, 'Starter', '30', '10', 'USD', 'test', 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyMvYRe'),
(2, 'Advanced', '365', '50', 'USD', 'test', 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyMvYRe'),
(4, 'Super Premium', '366', '99', 'USD', 'test', 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyMvYRe');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_suggest`
--

CREATE TABLE `tbl_suggest` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `suggest_title` varchar(500) NOT NULL,
  `suggest_image` varchar(255) DEFAULT NULL,
  `suggest_message` text DEFAULT NULL,
  `suggest_on` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaction`
--

CREATE TABLE `tbl_transaction` (
  `id` int(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `plan_name` varchar(255) NOT NULL,
  `plan_price` varchar(255) NOT NULL,
  `date_time` varchar(255) NOT NULL,
  `end_date_time` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `id` int(10) NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'Normal',
  `user_name` varchar(60) NOT NULL,
  `user_email` varchar(70) NOT NULL,
  `user_password` text NOT NULL,
  `user_phone` varchar(20) NOT NULL,
  `user_gender` varchar(255) NOT NULL,
  `profile_img` varchar(255) NOT NULL DEFAULT '0',
  `auth_id` varchar(255) NOT NULL DEFAULT '0',
  `registered_on` varchar(200) NOT NULL DEFAULT '0',
  `status` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_web_settings`
--

CREATE TABLE `tbl_web_settings` (
  `id` int(2) NOT NULL,
  `admin_panel` text NOT NULL,
  `site_name` text NOT NULL,
  `site_description` text NOT NULL,
  `site_keywords` text NOT NULL,
  `copyright_text` text NOT NULL,
  `web_logo_1` text NOT NULL,
  `web_logo_2` text NOT NULL,
  `web_favicon` text NOT NULL,
  `header_code` longtext NOT NULL,
  `footer_code` longtext NOT NULL,
  `contact_page_title` varchar(150) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact_number` varchar(60) NOT NULL,
  `contact_email` varchar(60) NOT NULL,
  `android_app_url` text NOT NULL,
  `ios_app_url` text NOT NULL,
  `facebook_url` text NOT NULL,
  `twitter_url` text NOT NULL,
  `youtube_url` text NOT NULL,
  `instagram_url` text NOT NULL,
  `about_page_title` varchar(150) NOT NULL,
  `about_content` longtext NOT NULL,
  `about_status` varchar(10) NOT NULL DEFAULT 'true',
  `privacy_page_title` varchar(150) NOT NULL,
  `privacy_content` longtext NOT NULL,
  `privacy_page_status` varchar(10) NOT NULL DEFAULT 'true',
  `terms_of_use_page_title` varchar(150) NOT NULL,
  `terms_of_use_content` longtext NOT NULL,
  `terms_of_use_page_status` varchar(10) NOT NULL DEFAULT 'true'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `tbl_web_settings`
--

INSERT INTO `tbl_web_settings` (`id`, `admin_panel`, `site_name`, `site_description`, `site_keywords`, `copyright_text`, `web_logo_1`, `web_logo_2`, `web_favicon`, `header_code`, `footer_code`, `contact_page_title`, `address`, `contact_number`, `contact_email`, `android_app_url`, `ios_app_url`, `facebook_url`, `twitter_url`, `youtube_url`, `instagram_url`, `about_page_title`, `about_content`, `about_status`, `privacy_page_title`, `privacy_content`, `privacy_page_status`, `terms_of_use_page_title`, `terms_of_use_content`, `terms_of_use_page_status`) VALUES
(1, '', 'Online Radio', 'This is developed using the popular PHP framework Codeigniter. Online Radio this is website application for Radio.', 'streaming, platform, Online Radio', 'Copyright © 2021 Online Radio- Radio Web Application, All rights reserved.', '26468_web_logo.jpg', 'logo.jpg', '93716_web_favicon.jpg', '', '', '', 'your Address', '+7463459646', 'info.nemosofts@gnail.com', 'https://play.google.com/store/apps/details?id=com.app.name', 'https://www.apple.com/app-store/', 'https://www.facebook.com/', 'https://twitter.com', 'https://www.youtube.com/', 'https://www.instagram.com/', 'About Us', '', 'true', 'Privacy Policy', '', 'true', 'Terms & Services', '', 'true');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_active_log`
--
ALTER TABLE `tbl_active_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_countries`
--
ALTER TABLE `tbl_countries`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `tbl_episode`
--
ALTER TABLE `tbl_episode`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_favourite`
--
ALTER TABLE `tbl_favourite`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_home_sections`
--
ALTER TABLE `tbl_home_sections`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_notification`
--
ALTER TABLE `tbl_notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_podcast`
--
ALTER TABLE `tbl_podcast`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `tbl_policy_deletion`
--
ALTER TABLE `tbl_policy_deletion`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_radio`
--
ALTER TABLE `tbl_radio`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_radio_views`
--
ALTER TABLE `tbl_radio_views`
  ADD PRIMARY KEY (`view_id`);

--
-- Indexes for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_reports`
--
ALTER TABLE `tbl_reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sidebar`
--
ALTER TABLE `tbl_sidebar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_smtp_settings`
--
ALTER TABLE `tbl_smtp_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_subscription`
--
ALTER TABLE `tbl_subscription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_suggest`
--
ALTER TABLE `tbl_suggest`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_transaction`
--
ALTER TABLE `tbl_transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_web_settings`
--
ALTER TABLE `tbl_web_settings`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_active_log`
--
ALTER TABLE `tbl_active_log`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_banner`
--
ALTER TABLE `tbl_banner`
  MODIFY `bid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_countries`
--
ALTER TABLE `tbl_countries`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_episode`
--
ALTER TABLE `tbl_episode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_favourite`
--
ALTER TABLE `tbl_favourite`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_home_sections`
--
ALTER TABLE `tbl_home_sections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_notification`
--
ALTER TABLE `tbl_notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_podcast`
--
ALTER TABLE `tbl_podcast`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_policy_deletion`
--
ALTER TABLE `tbl_policy_deletion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_radio`
--
ALTER TABLE `tbl_radio`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_radio_views`
--
ALTER TABLE `tbl_radio_views`
  MODIFY `view_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_rating`
--
ALTER TABLE `tbl_rating`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_reports`
--
ALTER TABLE `tbl_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_sidebar`
--
ALTER TABLE `tbl_sidebar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_smtp_settings`
--
ALTER TABLE `tbl_smtp_settings`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_subscription`
--
ALTER TABLE `tbl_subscription`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_suggest`
--
ALTER TABLE `tbl_suggest`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_transaction`
--
ALTER TABLE `tbl_transaction`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_web_settings`
--
ALTER TABLE `tbl_web_settings`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;