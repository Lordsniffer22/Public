<?php 
    $page_title=(isset($_GET['radio_id'])) ? 'Edit Radio' : 'Add Radio';
    include("includes/header.php");
    require("includes/lb_helper.php");
    require("language/language.php");
    require_once("thumbnail_images.class.php");
    
    $page_save=(isset($_GET['radio_id'])) ? 'Save' : 'Create';
    
    $cat_qry="SELECT * FROM tbl_category ORDER BY category_name";
    $cat_result=mysqli_query($mysqli,$cat_qry); 
    
    $cou_qry="SELECT * FROM tbl_countries ORDER BY countries_name";
    $cou_result=mysqli_query($mysqli,$cou_qry); 
    
    if(isset($_POST['submit']) and isset($_GET['add'])){
        
        $ext = pathinfo($_FILES['radio_image']['name'], PATHINFO_EXTENSION);
        $radio_image=rand(0,99999)."_radio.".$ext;
        $tpath1='images/'.$radio_image;
        
        if($ext!='png')  {
            $pic1=compress_image($_FILES["radio_image"]["tmp_name"], $tpath1, 80);
        } else {
            $tmp = $_FILES['radio_image']['tmp_name'];
            move_uploaded_file($tmp, $tpath1);
        }
        
        $data = array( 
            'cat_id'  =>  $_POST['cat_id'],
            'countries_id'  =>  $_POST['countries_id'],
            'radio_title'  =>  cleanInput($_POST['radio_title']),
            'isPremium'  =>  $_POST['isPremium'],
            'radio_url'  =>  $_POST['radio_url'],
            'radio_image'  =>  $radio_image,
            'radio_description'  =>  addslashes(trim($_POST['radio_description']))
        );
        
        $qry = Insert('tbl_radio',$data);
        
        $_SESSION['msg']="10";
        $_SESSION['class']='success';
        header( "Location:create_radio.php?add=yes");
        exit;
    }
    
    if(isset($_GET['radio_id'])){
        $qry="SELECT * FROM tbl_radio where id='".$_GET['radio_id']."'";
        $result=mysqli_query($mysqli,$qry);
        $row=mysqli_fetch_assoc($result);
    }
    
    if(isset($_POST['submit']) and isset($_POST['radio_id'])){
        
        if($_FILES['radio_image']['name']!=""){
            
            if($row['radio_image']!=""){
                unlink('images/'.$row['radio_image']);
            }
            
            $ext = pathinfo($_FILES['radio_image']['name'], PATHINFO_EXTENSION);
            $radio_image=rand(0,99999)."_radio.".$ext;
            $tpath1='images/'.$radio_image;   
            
            if($ext!='png')  {
                $pic1=compress_image($_FILES["radio_image"]["tmp_name"], $tpath1, 80);
            } else {
                $tmp = $_FILES['radio_image']['tmp_name'];
                move_uploaded_file($tmp, $tpath1);
            }
        } else {
            $radio_image=$row['radio_image'];
        }
        
        $data = array( 
            'cat_id'  =>  $_POST['cat_id'],
            'countries_id'  =>  $_POST['countries_id'],
            'radio_title'  =>  cleanInput($_POST['radio_title']),
            'isPremium'  =>  $_POST['isPremium'],
            'radio_url'  =>  $_POST['radio_url'],
            'radio_image'  =>  $radio_image,
            'radio_description'  =>  addslashes(trim($_POST['radio_description']))
        ); 
        
        $category_edit=Update('tbl_radio', $data, "WHERE id = '".$_POST['radio_id']."'");
        
        $_SESSION['msg']="11";
        $_SESSION['class']='success';
        header( "Location:create_radio.php?radio_id=".$_POST['radio_id']);
        exit;
    }
?>

<!-- Start: main -->
<main id="nsofts_main">
    <div class="nsofts-container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb align-items-center">
                <li class="breadcrumb-item d-inline-flex"><a href="dashboard.php"><i class="ri-home-4-fill"></i></a></li>
                <li class="breadcrumb-item d-inline-flex active" aria-current="page"><?php echo (isset($page_title)) ? $page_title : "" ?></li>
            </ol>
        </nav>
            
        <div class="row g-4">
            <div class="col-12">
                <div class="card h-100">
                    <div class="card-body p-4">
                        <h5 class="mb-3"><?=$page_title ?></h5>
                        <form action="" name="addeditradio" method="POST" enctype="multipart/form-data">
                            <input  type="hidden" name="radio_id" value="<?=(isset($_GET['radio_id'])) ? $_GET['radio_id'] : ''?>" />
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Category</label>
                                <div class="col-sm-10">
                                    <select name="cat_id" id="cat_id" class="nsofts-select" required>
                                        <option value="">--Select Category--</option>
                                        <?php while($cat_row=mysqli_fetch_array($cat_result)){ ?>      
                                            <?php if(isset($_GET['radio_id'])){ ?>
                                                <option value="<?php echo $cat_row['cid'];?>" <?php if($cat_row['cid']==$row['cat_id']){?>selected<?php }?>><?php echo $cat_row['category_name'];?></option>	          							 
                                            <?php } else { ?>
                                                <option value="<?php echo $cat_row['cid'];?>"><?php echo $cat_row['category_name'];?></option>   							 
                                            <?php } ?>
                                        <?php } ?> 
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Countries</label>
                                <div class="col-sm-10">
                                    <select name="countries_id" id="countries_id" class="nsofts-select" required>
                                        <option value="">--Select Countries--</option>
                                        <?php while($cou_row=mysqli_fetch_array($cou_result)){ ?>      
                                            <?php if(isset($_GET['radio_id'])){ ?>
                                                <option value="<?php echo $cou_row['sid'];?>" <?php if($cou_row['sid']==$row['countries_id']){?>selected<?php }?>><?php echo $cou_row['countries_name'];?></option>	          							 
                                            <?php } else { ?>
                                                <option value="<?php echo $cou_row['sid'];?>"><?php echo $cou_row['countries_name'];?></option>   							 
                                            <?php } ?>
                                        <?php } ?> 
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Radio title</label>
                                <div class="col-sm-10">
                                     <input type="text" name="radio_title" class="form-control" value="<?php if(isset($_GET['radio_id'])){echo $row['radio_title'];}?>" required>
                                </div>
                            </div>

                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Type</label>
                                <div class="col-sm-10">
                                    <select name="isPremium" id="isPremium" class="nsofts-select" required>
                                        <?php if(isset($_GET['radio_id'])){ ?>
                                            <option value="false" <?php if($row['isPremium']=='false'){?>selected<?php }?>>Free</option>
                                            <option value="true" <?php if($row['isPremium']=='true'){?>selected<?php }?>>Premium</option>
                                        <?php } else { ?>
                                        	<option value="false">Free</option>
                                            <option value="true">Premium</option>
                                        <?php } ?> 
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Radio URL</label>
                                <div class="col-sm-10">
                                     <input type="text" name="radio_url" class="form-control" value="<?php if(isset($_GET['radio_id'])){echo $row['radio_url'];}?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Description</label>
                                <div class="col-sm-10">
                                     <textarea name="radio_description" id="radio_description" rows="5" class="nsofts-editor"><?php if(isset($_GET['radio_id'])){echo $row['radio_description'];}?></textarea>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">Select Image</label>
                                    <div class="col-sm-10">
                                        <input type="file" class="form-control-file" name="radio_image"   accept=".png, .jpg, .JPG .PNG" onchange="fileValidation()" id="fileupload" <?php if(!isset($_GET['radio_id'])){?>required<?php } ?>>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                        <div class="fileupload_img" id="imagePreview">
                                            <?php if(isset($_GET['radio_id']) AND file_exists('images/'.$row['radio_image'])) {?>
                                              <img class="col-sm-2 img-thumbnail" type="image" src="images/<?php echo $row['radio_image'];?>" alt="image" />
                                            <?php }else{?>
                                              <img class="col-sm-2 img-thumbnail" type="image" src="assets/images/300x300.jpg" alt="image" />
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                        <button type="submit" name="submit" class="btn btn-primary" style="min-width: 120px;"><?=$page_save?></button>
                                    </div>
                                </div>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- End: main -->
    
<?php include("includes/footer.php");?> 