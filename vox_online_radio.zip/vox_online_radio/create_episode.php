<?php 
    $page_title=(isset($_GET['episode_id'])) ? 'Edit Episode' : 'Create Episode';
    include("includes/header.php");
    require("includes/lb_helper.php");
    require("language/language.php");
    require_once("thumbnail_images.class.php");
    
    $page_save=(isset($_GET['cat_id'])) ? 'Save' : 'Create';
    
    $podcas_qry="SELECT * FROM tbl_podcast ORDER BY tbl_podcast.`pid` DESC";
    $podcas_result=mysqli_query($mysqli,$podcas_qry); 
    
    if(isset($_POST['submit']) and isset($_GET['add'])){
        
        $data = array( 
            'podcast_id'  =>  $_POST['podcast_id'],
            'episode_title'  =>  cleanInput($_POST['episode_title']),
            'episode_url'  =>  $_POST['episode_url']
        );
        
        $qry = Insert('tbl_episode',$data);
        
        $_SESSION['msg']="10";
        $_SESSION['class']='success';
        header( "Location:create_episode.php?add=yes");
        exit;
    }
    
    if(isset($_GET['episode_id'])){
        $qry="SELECT * FROM tbl_episode where id='".$_GET['episode_id']."'";
        $result=mysqli_query($mysqli,$qry);
        $row=mysqli_fetch_assoc($result);
    }
    
    if(isset($_POST['submit']) and isset($_POST['episode_id'])){
        
        $data = array( 
            'podcast_id'  =>  $_POST['podcast_id'],
            'episode_title'  =>  cleanInput($_POST['episode_title']),
            'episode_url'  =>  $_POST['episode_url']
        ); 
        
        $category_edit=Update('tbl_episode', $data, "WHERE id = '".$_POST['episode_id']."'");
        
        $_SESSION['msg']="11";
        $_SESSION['class']='success';
        header( "Location:create_episode.php?episode_id=".$_POST['episode_id']);
        exit;
    }
?>

<!-- Start: main -->
<main id="nsofts_main">
    <div class="nsofts-container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb align-items-center">
                <li class="breadcrumb-item d-inline-flex"><a href="dashboard.php"><i class="ri-home-4-fill"></i></a></li>
                <li class="breadcrumb-item d-inline-flex active" aria-current="page"><?php echo (isset($page_title)) ? $page_title : "" ?></li>
            </ol>
        </nav>
            
        <div class="row g-4">
            <div class="col-12">
                <div class="card h-100">
                    <div class="card-body p-4">
                        <h5 class="mb-3"><?=$page_title ?></h5>
                        <form action="" name="addeditepisode" method="POST" enctype="multipart/form-data">
                            <input  type="hidden" name="episode_id" value="<?=(isset($_GET['episode_id'])) ? $_GET['episode_id'] : ''?>" />
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Podcast</label>
                                <div class="col-sm-10">
                                    <select name="podcast_id" id="podcast_id" class="nsofts-select" required>
                                        <option value="">--Select Podcast--</option>
                                        <?php while($podcas_row=mysqli_fetch_array($podcas_result)){ ?>
                                            <?php if(isset($_GET['episode_id'])){ ?>
                                                <option value="<?php echo $podcas_row['pid'];?>" <?php if($podcas_row['pid']==$row['podcast_id']){?>selected<?php }?>><?php echo $podcas_row['podcast_name'];?></option>   							 
                                            <?php } else { ?>
                                                <option value="<?php echo $podcas_row['pid'];?>"><?php echo $podcas_row['podcast_name'];?></option>
                                            <?php } ?>
                                        <?php } ?> 
                                    </select>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">Title</label>
                                <div class="col-sm-10">
                                     <input type="text" name="episode_title" class="form-control" value="<?php if(isset($_GET['episode_id'])){echo $row['episode_title'];}?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <label class="col-sm-2 col-form-label">URL</label>
                                <div class="col-sm-10">
                                     <input type="text" name="episode_url" class="form-control" value="<?php if(isset($_GET['episode_id'])){echo $row['episode_url'];}?>" required>
                                </div>
                            </div>
                            
                            <div class="mb-3 row">
                                <div class="mb-3 row">
                                    <label class="col-sm-2 col-form-label">&nbsp;</label>
                                    <div class="col-sm-10">
                                        <button type="submit" name="submit" class="btn btn-primary" style="min-width: 120px;"><?=$page_save?></button>
                                    </div>
                                </div>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<!-- End: main -->
    
<?php include("includes/footer.php");?> 